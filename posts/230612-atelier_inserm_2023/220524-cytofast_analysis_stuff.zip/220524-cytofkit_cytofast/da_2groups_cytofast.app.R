# Start a RStudio project in the result analysis directory of cytofkit


# Install the packages if not already done

if (require(shiny) == FALSE)
    install.packages(c("shiny", "readxl", "writexl", "brew", "rmarkdown"))

library(shiny)

library(readxl)
library(writexl)
library(flowCore)
library(brew)

# Guess where FCS files are located
fcs_dirs <- unique(dirname(dir(pattern = "*fcs$", recursive = TRUE)))

# Define UI for application
ui <- fluidPage(
    
    # Application title
    titlePanel("cytofast GUI"),
    
    # Tabs
    tabsetPanel(
        tabPanel(
"Design",
br(),
p("Define the experimental design",
  br(),
  "You will assign an experimental group to each FCS file and
  define the markers to help identifying cells clusters."),
textInput(
    "proc_dir", "Name of the design", ""),
selectInput(
    "fcs_dir", "Location of FCS to analyze", choices = fcs_dirs),
# textInput("element", "Parent directory for FCS retrieval is", getwd()),
# shinyDirButton("directory", "Folder select", "Please select a folder"),
# p("Select FCS files"),
# shinyFilesButton("file", "File select", "Please select a file", multiple = TRUE, viewtype = "detail"),
# Templates
# actionButton("write_panel", "Write the panel file"),
# actionButton("write_metadat", "Write the metadata file"),
actionButton(
    "create_design", "Create design")
        ), 
        tabPanel(
"Diff Abund 2 gr",
br(),
p("Set up the differential abundance analysis",
  br(),
  "Define the parameters of the analysis for grouping samples, 
  reporting cells clusters statistically significant between groups and 
  visualizing the volcano plot."),
textInput(
    "da2gr_dir", "Name of the analysis", ""),
uiOutput(
    "selected_design"),
textInput(
    "asinh_cofactor", "Asinh cofactor for scaling", 
    value = 5),
uiOutput(
    "selected_clustering"),
# uiOutput(
#     "markers_pheno"),
uiOutput(
    "condition"),
uiOutput(
    "condition_ref"),
numericInput(
    "pvalue_cut", "P-value threshold", 
    value = 0.05),
numericInput(
    "logfold_cut", "Logfold threshold", 
    value = 2),
# Generate the analysis template
actionButton(
    "create_script", "Create script"),
# shinySaveButton("save", "Save file", "Save file as...", filetype = list(text = "txt", picture = c("jpeg", "jpg")), viewtype = "icon"),
br(),
uiOutput(
    "download_ui")
        )
    ),
textOutput("create_dir_log")
    
)

# Define server logic 
server <- function(input, output, session) {
    
    config_script <- reactiveValues(
        design_new = "",
        proc_dir = "",
        design_dir = "",
        fcs_dir = "",
        fcs_parameters = "",
        markers = "",
        # markers_pheno = "",
        clusterings = "",
        selected_clustering = "",
        asinh_cofactor = 5,
        conditions = "",
        condition = "condition",
        condition_levels = "",
        condition_ref = "",
        pvalue.cut = 0.05,
        logFold.cut = 1  # log fold change
    )

    observeEvent(input$create_design, {
        # inputs
        fcs_dir = req(isolate(input$fcs_dir))
        proc_dir = req(isolate(input$proc_dir))
        # checks
        stopifnot(dir.exists(fcs_dir))
        # read FCS
        fcs_files = dir(fcs_dir, pattern = "\\.fcs$", full.names = TRUE)
        fs = flowCore::read.flowSet(fcs_files, which.lines = 1:20)
        # create directory for analysis
        proc_dir <- paste(timetag(), "design", proc_dir, sep = "-")
        dir.create(proc_dir)
        # metadata
        metadt = data.frame(
            file_name = fcs_files,
            sample_id = gsub("\\.fcs$", "", basename(fcs_files), ignore.case = TRUE),
            patient_id = seq(fcs_files),
            condition = rep(c("treated", "control"), length(fcs_files))[seq(fcs_files)]
        )
        # panel
        pd = pData(parameters(fs[[1]]))
        pd[is.na(pd)] = ""
        # TODO: remove Time...
        # TODO: clean antigen names
        # TODO: guess class from names
        panel = data.frame(
            fcs_colname = pd$name,
            antigen = pd$desc,
            marker_class = "type",
            stringsAsFactors = FALSE
        )
        is_clustr = grepl("_clusterIDs$", panel$fcs_colname)
        panel$marker_class[is_clustr] = "cluster"
        is_dimred = (grepl("^pca_", panel$fcs_colname) |
            grepl("^tsne_", panel$fcs_colname) |
            grepl("^umap_", panel$fcs_colname))
        panel$marker_class[is_dimred] = "dimred"
        is_ignored = grepl("time", panel$fcs_colname, ignore.case = TRUE) |
            grepl("length", panel$fcs_colname) |
            grepl("^[0-9]+$", panel$fcs_colname) |
            grepl("_linear$", panel$fcs_colname) |
            grepl("_cor_", panel$fcs_colname)
        panel$marker_class[is_ignored] = ""
        # write files
        writexl::write_xlsx(panel, file.path(proc_dir, "panel.xlsx"))
        writexl::write_xlsx(metadt, file.path(proc_dir, "metadata.xlsx"))
        # update flag
        config_script$design_new <- runif(1)
        # update configuration for script
        # markers <- colnames(fs)
        # markers_clusterings <- grep("clusterIDs", markers, value = TRUE)
        # config_script[["fcs_dir"]] <- fcs_dir
        # config_script[["clusterings"]] <- markers_clusterings
        # config_script[["markers"]] <- markers
        # config_script[["fcs_parameters"]] <- parameters(fs[[1]])
    })
    
    output$selected_design <- renderUI({
        config_script$design_new
        ldir <- list.dirs(recursive = FALSE)
        ldir <- grep("-design-", ldir, value = TRUE)
        req(ldir)
        lname <- gsub("^\\./", "", ldir)
        lname <- gsub("-design-", "-", lname)
        lchoices <- as.list(ldir)
        names(lchoices) <- lname
        selectInput(
            "selected_design", "Design to use", 
            choices = lchoices)
    })
    
    observeEvent(input$selected_design, {
        req(input$selected_design)
        proc_dir <- input$selected_design
        panel_ed <- readxl::read_xlsx(
            file.path(proc_dir, "panel.xlsx"))
        metadt_ed <- readxl::read_xlsx(
            file.path(proc_dir, "metadata.xlsx"))
        panel_ed <- as.data.frame(panel_ed)
        metadt_ed <- as.data.frame(metadt_ed)
        config_script$design_dir <- proc_dir
        # FCS dir
        config_script$fcs_dir <- unique(dirname(metadt_ed$file_name))[1]
        # markers
        markers <- panel_ed$antigen
        # markers_pheno <- markers[panel_ed$type == "type"]
        clusterings <- grepl("cluster", panel_ed$marker_class)
        clusterings <- panel_ed$fcs_colname[clusterings]
        # conditions
        conditions <- colnames(metadt_ed)
        conditions <- setdiff(conditions, c("file_name", "sample_id", "patient_id"))
        # update
        config_script$panel <- panel_ed
        config_script$metadt <- metadt_ed
        config_script$markers <- markers
        # config_script$markers_pheno <- markers_pheno
        config_script$conditions <- conditions
        config_script$clusterings <- clusterings
    })
    
    output$selected_clustering <- renderUI({
        req(config_script$clusterings)
        selectInput(
            "selected_clustering", "Clustering to report", 
            choices = config_script$clusterings)
    })
    
    # output$markers_pheno <- renderUI({
    #     # selectInput(
    #     #     "markers_pheno", "Markers for phenotyping clusters", 
    #     #     choices = config_script$markers)
    #     selectizeInput(
    #         "markers_pheno", "Markers for phenotyping clusters", 
    #         choices = config_script$markers,
    #         selected = config_script$markers,
    #         multiple = TRUE)
    # })
    
    output$condition <- renderUI({
        req(config_script$conditions)
        selectInput(
            "condition", "Column to group FCS", 
            choices = config_script$conditions)
    })
    
    output$condition_ref <- renderUI({
        req(config_script$metadt)
        if (!is.null(input$condition)) {
            condition <- factor(config_script$metadt[,input$condition])
            condition_levels <- levels(condition)
        } else {
            condition_levels <- ""
        }
        selectInput(
            "condition_ref", "Reference group", 
            choices = condition_levels)
    })
    
    observeEvent(input$create_script, {
        req(input$da2gr_dir)
        # output dir
        da2gr_dir <- paste(timetag(), "da2gr", input$da2gr_dir, sep = "-")
        da2gr_file <- "da_2groups_cytofast.Rmd"
        # get latest parameters
        # config_script$proc_dir <- da2gr_dir
        config_script$selected_clustering <- isolate(input$selected_clustering)
        config_script$pvalue_cut <- isolate(input$pvalue_cut)
        config_script$condition <- isolate(input$condition)
        config_script$condition_ref <- isolate(input$condition_ref)
        config_script$pvalue_cut <- isolate(input$pvalue_cut)
        config_script$logfold_cut <- isolate(input$logfold_cut)
        config_env <- isolate(reactiveValuesToList(config_script))
        config_env <- list2env(config_env, parent = .GlobalEnv)
        # output
        config_script$da2gr_dir <- da2gr_dir
        config_script$da2gr_file <- gsub("Rmd$", "html", da2gr_file)
        dir.create(da2gr_dir)
        rmd_file <- file.path(da2gr_dir, da2gr_file)
        brew(
          file = paste0(da2gr_file, ".brew"), 
          output = rmd_file,
          envir = config_env)
        rmarkdown::render(
          input = rmd_file,
          output_format = "html_document")
    })
    
    output$download_ui <- renderUI({
      req(input$da2gr_dir)
      req(config_script$da2gr_dir)
      tags$div(
        br(),
        downloadButton("download_report", "Download report")
      )
    })

    output$download_report <- downloadHandler(
      filename = function() {
        config_script$da2gr_file
      },
      content = function(file) {
        file.copy(file.path(config_script$da2gr_dir, 
                            config_script$da2gr_file), file)
      },
      contentType = "text/html"
    )

}

# Misc
timetag <- function(
    file
) {
    tag <- sprintf("%08X", as.integer(Sys.time()) -
                       as.integer(as.POSIXct("2020-01-01 00:00")))
    if (missing(file)) return(tag)
    if (grepl("\\..{1,5}$", file)) {
        gsub("(.+)(\\..{1,5}$)", paste0("\\1-", tag, "\\2"), file)
    } else {
        paste0(file, "-", tag)
    }
}

# Run the application 
shinyApp(ui = ui, server = server)
